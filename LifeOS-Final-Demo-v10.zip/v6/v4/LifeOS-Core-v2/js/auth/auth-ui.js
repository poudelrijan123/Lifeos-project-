/** Local-only demo authentication. No credentials are sent to any provider or server. */
export function initAuth({ onDemo }) {
  const $ = id => document.getElementById(id);
  let mode = "signin";
  const message = (text, kind = "") => { $("auth-message").textContent = text; $("auth-message").className = `auth-message ${kind}`; };
  const setMode = next => {
    mode = next; const signup = mode === "signup";
    $("tab-signin").classList.toggle("active", !signup); $("tab-signup").classList.toggle("active", signup);
    $("tab-signin").setAttribute("aria-selected", String(!signup)); $("tab-signup").setAttribute("aria-selected", String(signup));
    $("auth-title").textContent = signup ? "Create your demo profile" : "Enter your demo space";
    $("auth-subtitle").textContent = "Preview LifeOS locally. No real account is created.";
    $("name-field").classList.toggle("hidden", !signup);
    $("confirm-field").classList.add("hidden");
    const passwordLabel = $("auth-password").closest("label");
    if (passwordLabel) passwordLabel.classList.add("hidden");
    $("signin-meta").classList.add("hidden");
    $("auth-submit").querySelector("span:first-child").textContent = signup ? "Create demo profile" : "Continue to LifeOS";
    message("Demo only: do not enter real passwords or sensitive information.");
  };
  $("tab-signin").addEventListener("click", () => setMode("signin"));
  $("tab-signup").addEventListener("click", () => setMode("signup"));
  $("auth-form").addEventListener("submit", event => {
    event.preventDefault(); message("");
    const email = $("auth-email").value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return message("Enter a valid email address for your demo profile.");
    const name = mode === "signup" ? $("auth-name").value.trim() : (email.split("@")[0] || "LifeOS user");
    if (mode === "signup" && !name) return message("Enter a display name.");
    onDemo({ name, email, provider: "email-demo" });
  });
  document.querySelectorAll("[data-provider]").forEach(button => button.addEventListener("click", () => {
    const provider = button.dataset.provider;
    onDemo({ name: `${provider[0].toUpperCase()}${provider.slice(1)} demo user`, provider: `${provider}-demo` });
  }));
  $("forgot-password").addEventListener("click", () => message("Password reset is not part of this local demo."));
  $("demo-entry").addEventListener("click", () => onDemo({ name: "Guest", provider: "guest-demo" }));
  $("terms-link").addEventListener("click", e => e.preventDefault());
  $("privacy-link").addEventListener("click", e => e.preventDefault());
  setMode("signin");
}
