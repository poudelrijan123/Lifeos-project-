// Local demo build: no backend URL, API key, OAuth or remote authentication.
export const AUTH_CONFIG = Object.freeze({ provider: "demo", url: "", anonKey: "" });
export const isAuthConfigured = () => false;
