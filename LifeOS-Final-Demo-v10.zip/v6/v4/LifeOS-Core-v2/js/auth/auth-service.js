import { AUTH_CONFIG, isAuthConfigured } from "./config.js";

/** Thin auth boundary. Provider credentials belong in the provider dashboard/backend, never in this repo. */
export class AuthService {
  constructor(config = AUTH_CONFIG) { this.config = config; }
  get configured() { return Boolean(this.config.url && this.config.anonKey); }
  saveSession(data) {
    if (data?.access_token) sessionStorage.setItem("lifeos.auth.session", JSON.stringify({access_token:data.access_token,refresh_token:data.refresh_token||"",expires_at:Date.now()+(Number(data.expires_in)||3600)*1000,token_type:data.token_type||"bearer"}));
    return data;
  }
  async getCurrentSession() {
    const raw=sessionStorage.getItem("lifeos.auth.session"); if(!raw)return null;
    let session; try{session=JSON.parse(raw)}catch{sessionStorage.removeItem("lifeos.auth.session");return null}
    if(session.expires_at<Date.now()+30000&&session.refresh_token){
      const response=await fetch(`${this.config.url.replace(/\/$/,"")}/auth/v1/token?grant_type=refresh_token`,{method:"POST",headers:{"Content-Type":"application/json",apikey:this.config.anonKey},body:JSON.stringify({refresh_token:session.refresh_token})});
      const refreshed=await response.json().catch(()=>({})); if(!response.ok){sessionStorage.removeItem("lifeos.auth.session");return null} this.saveSession(refreshed);session=JSON.parse(sessionStorage.getItem("lifeos.auth.session"));
    }
    const response=await fetch(`${this.config.url.replace(/\/$/,"")}/auth/v1/user`,{headers:{apikey:this.config.anonKey,Authorization:`Bearer ${session.access_token}`}});
    if(!response.ok){sessionStorage.removeItem("lifeos.auth.session");return null} return {...session,user:await response.json()};
  }
  async consumeOAuthCallback() {
    const params=new URLSearchParams(window.location.hash.slice(1)); const error=params.get("error_description")||params.get("error");
    if(error){history.replaceState({},document.title,window.location.pathname+window.location.search);throw new Error(error.replace(/\+/g," "))}
    const accessToken=params.get("access_token");if(!accessToken)return null;
    const payload={access_token:accessToken,refresh_token:params.get("refresh_token")||"",expires_in:Number(params.get("expires_in"))||3600,token_type:params.get("token_type")||"bearer"};
    this.saveSession(payload);history.replaceState({},document.title,window.location.pathname+window.location.search);
    const response=await fetch(`${this.config.url.replace(/\/$/,"")}/auth/v1/user`,{headers:{apikey:this.config.anonKey,Authorization:`Bearer ${accessToken}`}});
    if(!response.ok){sessionStorage.removeItem("lifeos.auth.session");throw new Error("Could not verify your sign-in. Please try again.")}
    return {...payload,user:await response.json()};
  }
  async signInWithPassword(email, password) {
    if (!this.config.url || !this.config.anonKey) throw new Error("Email sign-in is not connected yet. Configure the authentication project first.");
    const response = await fetch(`${this.config.url.replace(/\/$/, "")}/auth/v1/token?grant_type=password`, {
      method: "POST", headers: { "Content-Type": "application/json", apikey: this.config.anonKey },
      body: JSON.stringify({ email, password })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.msg || data.message || data.error_description || "Sign-in failed. Check your details and try again.");
    return this.saveSession(data);
  }
  async signUp(email, password, name) {
    if (!this.config.url || !this.config.anonKey) throw new Error("Account creation is not connected yet. Configure the authentication project first.");
    const response = await fetch(`${this.config.url.replace(/\/$/, "")}/auth/v1/signup`, {
      method: "POST", headers: { "Content-Type": "application/json", apikey: this.config.anonKey },
      body: JSON.stringify({ email, password, data: { full_name: name } })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.msg || data.message || data.error_description || "Could not create account.");
    return this.saveSession(data);
  }
  async signInWithProvider(provider) {
    if (!this.config.url || !this.config.anonKey) throw new Error(`${provider} sign-in is not configured yet.`);
    const url = new URL(`${this.config.url.replace(/\/$/, "")}/auth/v1/authorize`);
    url.searchParams.set("provider", provider);
    url.searchParams.set("redirect_to", window.location.origin + window.location.pathname);
    url.searchParams.set("flow_type", "implicit");
    window.location.assign(url.toString());
  }
}
