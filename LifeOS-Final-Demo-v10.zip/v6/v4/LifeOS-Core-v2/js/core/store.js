import { localDateKey } from "./date.js";

const KEY_PREFIX = "lifeos.core.v2";
const VERSION = 2;
const freshState = () => ({
  version: VERSION,
  createdAt: new Date().toISOString(),
  targets: [], tasks: [], habits: [], goals: [], measurements: [], focusSessions: [],
  settings: { lastActiveDate: localDateKey() }
});

/** Local persistence boundary. Each signed-in account and demo mode gets a separate namespace.
 * This is device-local storage, not cloud sync or a substitute for server-side authorization.
 */
export class Store {
  constructor(storage = globalThis.localStorage, scope = "demo") {
    this.storage = storage;
    this.scope = Store.normalizeScope(scope);
    this.key = `${KEY_PREFIX}.${this.scope}`;
    this.state = this.load();
  }
  static normalizeScope(scope) {
    const value = String(scope || "demo");
    if (value === "demo") return "demo";
    // Supabase user IDs are UUIDs. Restrict the namespace to safe, stable characters.
    return `user-${value.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 100)}`;
  }
  load() {
    try {
      let raw = this.storage?.getItem(this.key);
      // One-time migration of the old unscoped prototype data into demo mode only.
      if (!raw && this.scope === "demo") {
        raw = this.storage?.getItem(KEY_PREFIX);
        if (raw) this.storage?.setItem(this.key, raw);
      }
      if (!raw) return freshState();
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return freshState();
      if (parsed.version === 1) return { ...freshState(), ...parsed, version: VERSION };
      if (parsed.version !== VERSION) return freshState();
      return { ...freshState(), ...parsed };
    } catch { return freshState(); }
  }
  save() { this.storage?.setItem(this.key, JSON.stringify(this.state)); }
  update(mutator) { mutator(this.state); this.save(); return this.state; }
  export() {
    return JSON.stringify({ app: "LifeOS", version: VERSION, exportedAt: new Date().toISOString(), data: this.state }, null, 2);
  }
  import(text) {
    if (typeof text !== "string" || text.length > 5 * 1024 * 1024) throw new Error("Backup is too large. Maximum size is 5 MB.");
    const parsed = JSON.parse(text);
    if (parsed?.app !== "LifeOS" || !parsed.data || !Array.isArray(parsed.data.tasks) || !Array.isArray(parsed.data.habits) || !Array.isArray(parsed.data.measurements)) {
      throw new Error("This is not a valid LifeOS backup.");
    }
    const d = parsed.data;
    const limits = [["tasks", 2000], ["habits", 500], ["measurements", 20000], ["focusSessions", 10000], ["goals", 500], ["targets", 500]];
    for (const [key, max] of limits) if (d[key] !== undefined && (!Array.isArray(d[key]) || d[key].length > max)) throw new Error(`Backup contains invalid or excessive ${key} data.`);
    this.state = { ...freshState(), ...d, version: VERSION };
    this.save();
  }
  reset() { this.state = freshState(); this.save(); }
}
export { KEY_PREFIX as KEY, VERSION };
