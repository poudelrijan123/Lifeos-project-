import { localDateKey } from "./date.js";
export const METRICS = {
  steps:{label:"Steps",unit:"steps",daily:true},
  waterMl:{label:"Water",unit:"ml",daily:true},
  sleepMinutes:{label:"Sleep",unit:"min",daily:true},
  activeMinutes:{label:"Active time",unit:"min",daily:true},
  focusMinutes:{label:"Focus time",unit:"min",daily:true},
  heartRateBpm:{label:"Heart rate",unit:"bpm",daily:false}
};
export function setTarget(state, metric, targetValue) {
  if (!METRICS[metric] || !METRICS[metric].daily) throw new Error("This metric cannot have a daily target.");
  const value = Number(targetValue);
  if (!Number.isFinite(value) || value <= 0) throw new Error("Target must be a positive number.");
  const existing = state.targets.find(t => t.metric === metric);
  if (existing) { existing.targetValue = value; existing.updatedAt = new Date().toISOString(); }
  else state.targets.push({ id:crypto.randomUUID(), metric, targetValue:value, period:"daily", createdAt:new Date().toISOString() });
}
export function getTodayValue(state, metric, day = localDateKey()) {
  return state.measurements.filter(m => m.metric === metric && m.day === day).reduce((sum,m)=>sum + m.value,0);
}
export function targetProgress(state, target, day = localDateKey()) {
  const currentValue = getTodayValue(state, target.metric, day);
  const percent = Math.min(100, Math.round(currentValue / target.targetValue * 100));
  return { currentValue, targetValue:target.targetValue, percent, remaining:Math.max(0,target.targetValue-currentValue), complete:currentValue>=target.targetValue };
}
export function logMeasurement(state, metric, value, source = "manual", at = new Date()) {
  if (!METRICS[metric]) throw new Error("Unsupported metric.");
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) throw new Error("Value must be zero or greater.");
  state.measurements.push({ id:crypto.randomUUID(), metric, value:n, unit:METRICS[metric].unit, source, at:at.toISOString(), day:localDateKey(at) });
}