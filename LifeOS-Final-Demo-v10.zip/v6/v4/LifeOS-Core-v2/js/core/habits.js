import { localDateKey } from "./date.js";
export function addHabit(state,title) {
  const clean=String(title||"").trim();
  if(!clean) throw new Error("Habit name is required.");
  state.habits.push({id:crypto.randomUUID(),title:clean,createdAt:new Date().toISOString(),completedDays:[]});
}
export function toggleHabitToday(state,id,day=localDateKey()) {
  const h=state.habits.find(x=>x.id===id); if(!h) return;
  h.completedDays ||= [];
  h.completedDays = h.completedDays.includes(day) ? h.completedDays.filter(d=>d!==day) : [...h.completedDays,day];
}