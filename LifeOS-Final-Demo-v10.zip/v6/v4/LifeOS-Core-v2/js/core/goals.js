// Legacy goal-data helpers retained for backward compatibility and old backup tests.
// Goal tracking is no longer part of the active LifeOS dashboard.

export function addGoal(state, input) {
  const title=String(input?.title||"").trim(), targetValue=Number(input?.targetValue);
  if(!title) throw new Error("Goal title is required.");
  if(!Number.isFinite(targetValue)||targetValue<1) throw new Error("Goal target must be at least 1.");
  const goal={id:crypto.randomUUID(),title,targetValue,currentValue:0,unit:String(input?.unit||""),dueDate:input?.dueDate||null};
  state.goals ||= []; state.goals.push(goal); return goal;
}
export function updateGoalProgress(state,id,delta=1) {
  const goal=(state.goals||[]).find(item=>item.id===id); if(!goal) return null;
  goal.currentValue=Math.max(0,Math.min(goal.targetValue,goal.currentValue+Number(delta||0))); return goal;
}
export function deleteGoal(state,id) { state.goals=(state.goals||[]).filter(item=>item.id!==id); }
