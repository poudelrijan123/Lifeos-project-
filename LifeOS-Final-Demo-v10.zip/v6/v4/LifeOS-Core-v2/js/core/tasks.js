export function addTask(state, input) {
  const title = String(input.title || "").trim();
  if (!title) throw new Error("Task title is required.");
  state.tasks.unshift({ id:crypto.randomUUID(), title, priority:input.priority||"normal", category:input.category||"Personal", dueAt:input.dueAt||null, completedAt:null, createdAt:new Date().toISOString() });
}
export function completeTask(state, id) {
  const task = state.tasks.find(t=>t.id===id);
  if (task) task.completedAt = task.completedAt ? null : new Date().toISOString();
}
export function deleteTask(state,id) { state.tasks = state.tasks.filter(t=>t.id!==id); }