/**
 * LifeOS Bluetooth LE adapter.
 * Supports standard Bluetooth SIG GATT services when a peripheral exposes them.
 * Web Bluetooth requires HTTPS/localhost and a supporting browser (usually Chromium).
 * iOS Safari does not expose Web Bluetooth; use a native HealthKit/Capacitor host there.
 */
export const BLE_UUID = Object.freeze({
  heartRate: 0x180d, heartRateMeasurement: 0x2a37,
  battery: 0x180f, batteryLevel: 0x2a19,
  deviceInformation: 0x180a, manufacturerName: 0x2a29, modelNumber: 0x2a24,
  serialNumber: 0x2a25, firmwareRevision: 0x2a26
});

export function parseHeartRate(data) {
  if (!data || typeof data.getUint8 !== "function" || data.byteLength < 2) return null;
  const flags = data.getUint8(0);
  const is16Bit = Boolean(flags & 0x01);
  if (is16Bit && data.byteLength < 3) return null;
  const bpm = is16Bit ? data.getUint16(1, true) : data.getUint8(1);
  return Number.isInteger(bpm) && bpm > 0 && bpm <= 300 ? bpm : null;
}

function safeText(value) {
  return String(value || "").replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, 80);
}

export class LifeOSBluetooth {
  constructor({ onStatus = () => {}, onMeasurement = () => {} } = {}) {
    this.device = null;
    this.server = null;
    this.heartRateCharacteristic = null;
    this.onStatus = onStatus;
    this.onMeasurement = onMeasurement;
    this.onHeartRate = this.onHeartRate.bind(this);
    this.onDisconnected = this.onDisconnected.bind(this);
    this.status = "disconnected";
    this.lastMeasurementAt = 0;
  }
  get supported() {
    return typeof navigator !== "undefined" && !!navigator.bluetooth?.requestDevice;
  }
  setStatus(state, message, extra = {}) {
    this.status = state;
    this.onStatus({ state, message, ...extra });
  }
  async connect() {
    if (!this.supported) throw new Error("Bluetooth LE is unavailable in this browser. Use a compatible Chromium browser on Android/desktop, or a native iOS/Android build.");
    if (this.status === "connecting" || this.status === "connected") throw new Error("A Bluetooth connection is already active.");
    this.setStatus("scanning", "Choose a nearby Bluetooth device. Only pair with a device you trust.");
    try {
      this.device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [BLE_UUID.heartRate, BLE_UUID.battery, BLE_UUID.deviceInformation]
      });
      if (!this.device?.gatt) throw new Error("The selected device does not expose a Bluetooth GATT connection.");
      this.device.addEventListener("gattserverdisconnected", this.onDisconnected);
      this.setStatus("connecting", `Connecting to ${safeText(this.device.name) || "Bluetooth device"}…`);
      this.server = await this.device.gatt.connect();
      if (!this.server?.connected) throw new Error("The Bluetooth device did not establish a connection.");
      const info = await this.readDeviceInfo();
      await this.startHeartRate();
      const battery = await this.readBattery();
      const name = safeText(this.device.name) || "Bluetooth device";
      this.setStatus("connected", `Connected to ${name}. ${this.heartRateCharacteristic ? "Live heart-rate service active." : "No standard heart-rate service found."}`, { name, info, heartRate: Boolean(this.heartRateCharacteristic), battery });
      return { name, id: this.device.id, info, heartRate: Boolean(this.heartRateCharacteristic), battery };
    } catch (error) {
      if (this.device?.gatt?.connected) this.device.gatt.disconnect();
      if (error?.name === "NotFoundError") this.setStatus("disconnected", "No device selected.");
      else this.setStatus("disconnected", error?.message || "Bluetooth connection failed.");
      throw error;
    }
  }
  async readDeviceInfo() {
    const result = {};
    try {
      const service = await this.server.getPrimaryService(BLE_UUID.deviceInformation);
      const fields = [["manufacturer", BLE_UUID.manufacturerName], ["model", BLE_UUID.modelNumber], ["firmware", BLE_UUID.firmwareRevision]];
      for (const [key, uuid] of fields) {
        try { result[key] = safeText(new TextDecoder().decode(await (await service.getCharacteristic(uuid)).readValue())); } catch { /* optional characteristic */ }
      }
    } catch { /* optional service */ }
    return result;
  }
  async startHeartRate() {
    try {
      const service = await this.server.getPrimaryService(BLE_UUID.heartRate);
      const characteristic = await service.getCharacteristic(BLE_UUID.heartRateMeasurement);
      await characteristic.startNotifications();
      characteristic.addEventListener("characteristicvaluechanged", this.onHeartRate);
      this.heartRateCharacteristic = characteristic;
    } catch { this.heartRateCharacteristic = null; }
  }
  onHeartRate(event) {
    const bpm = parseHeartRate(event?.target?.value);
    if (!bpm || !this.device) return;
    const now = Date.now();
    if (now - this.lastMeasurementAt < 500) return;
    this.lastMeasurementAt = now;
    const record = { metric: "heartRateBpm", value: bpm, source: `BLE · ${safeText(this.device.name) || "Bluetooth device"}`, at: new Date(now).toISOString() };
    this.onMeasurement(record);
    this.setStatus("connected", `Connected · live heart rate ${bpm} bpm`, { name: safeText(this.device.name) || "Bluetooth device", heartRate: true, bpm });
  }
  async readBattery() {
    try {
      const service = await this.server.getPrimaryService(BLE_UUID.battery);
      const characteristic = await service.getCharacteristic(BLE_UUID.batteryLevel);
      const value = await characteristic.readValue();
      const percent = value.getUint8(0);
      if (percent > 100) return null;
      return percent;
    } catch { return null; }
  }
  onDisconnected() {
    this.server = null;
    this.heartRateCharacteristic = null;
    if (this.device) this.device.removeEventListener("gattserverdisconnected", this.onDisconnected);
    this.setStatus("disconnected", "Bluetooth device disconnected.");
  }
  disconnect() {
    const device = this.device;
    if (this.heartRateCharacteristic) {
      try { this.heartRateCharacteristic.removeEventListener("characteristicvaluechanged", this.onHeartRate); this.heartRateCharacteristic.stopNotifications(); } catch { /* device may already be gone */ }
    }
    if (device) device.removeEventListener("gattserverdisconnected", this.onDisconnected);
    this.heartRateCharacteristic = null;
    this.server = null;
    this.device = null;
    if (device?.gatt?.connected) device.gatt.disconnect();
    this.setStatus("disconnected", "Bluetooth disconnected.");
  }
}
