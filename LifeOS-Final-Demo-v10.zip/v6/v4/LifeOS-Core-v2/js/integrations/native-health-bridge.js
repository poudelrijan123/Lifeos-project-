/** Native iOS/Android health bridge boundary. Browser mode never simulates sensors. */
export function getNativeHealthBridge() {
  const bridge = globalThis.LifeOSHealthBridge;
  if (!bridge || typeof bridge.requestAuthorization !== "function" || typeof bridge.readToday !== "function") return null;
  return bridge;
}
export function getHealthBridgeStatus() {
  const bridge = getNativeHealthBridge();
  return { available: Boolean(bridge), platform: bridge?.platform || "web", capabilities: bridge?.capabilities || [] };
}
