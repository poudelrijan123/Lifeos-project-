import { initAuth } from "./auth/auth-ui.js";
import { Store } from "./core/store.js";
import { localDateKey, todayLabel } from "./core/date.js";
import { METRICS, logMeasurement } from "./core/targets.js";
import { addTask, completeTask, deleteTask } from "./core/tasks.js";
import { addHabit, toggleHabitToday } from "./core/habits.js";
import { AUTH_CONFIG, isAuthConfigured } from "./auth/config.js";
import { LifeOSBluetooth } from "./integrations/bluetooth.js";

const splash = document.getElementById("splash-screen");
if (splash) {
  const dismissSplash = () => { splash.hidden = true; };
  splash.addEventListener("animationend", event => {
    if (event.animationName === "splash-exit") dismissSplash();
  }, { once: true });
  // Fallback for browsers that skip CSS animation events.
  window.setTimeout(dismissSplash, window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 500 : 3400);
}
let store = null;
let welcomeTimer = null;
function showWelcome(user, isDemo = false) {
  const rawName = user?.user_metadata?.full_name || user?.user_metadata?.name || user?.name || user?.email?.split("@")[0] || (isDemo ? "there" : "there");
  const name = String(rawName).trim().split(/\s+/)[0].slice(0, 40) || "there";
  $("welcome-title").textContent = `Hi, ${name} 👋`;
  const toast = $("welcome-toast");
  toast.classList.remove("is-visible");
  toast.setAttribute("aria-hidden", "false");
  requestAnimationFrame(() => toast.classList.add("is-visible"));
  if (welcomeTimer) window.clearTimeout(welcomeTimer);
  welcomeTimer = window.setTimeout(() => {
    toast.classList.remove("is-visible");
    toast.setAttribute("aria-hidden", "true");
  }, 4200);
}
const enterApp = (scope, user = null, isDemo = false) => {
  store = new Store(globalThis.localStorage, scope);
  document.getElementById("auth-screen").hidden = true;
  document.getElementById("app-shell").hidden = false;
  render();
  runSecurityChecks();
  showWelcome(user, isDemo);
};
initAuth({
  onAuthenticated: session => {
    const accountId = session?.user?.id || session?.user?.sub;
    if (!accountId) {
      const message = document.getElementById("auth-message");
      if (message) message.textContent = "Sign-in did not return a valid account ID. Please try again.";
      return;
    }
    enterApp(accountId, session?.user);
  },
  onDemo: profile => enterApp("demo", profile ? { name: profile.name, email: profile.email } : null, true)
});
const $ = id => document.getElementById(id);
const escapeHtml = value => String(value).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const number = n => new Intl.NumberFormat().format(n);
$("welcome-dismiss").addEventListener("click", () => {
  const toast = $("welcome-toast");
  toast.classList.remove("is-visible");
  toast.setAttribute("aria-hidden", "true");
  if (welcomeTimer) window.clearTimeout(welcomeTimer);
});
const commit = fn => { if (!store) return; store.update(fn); render(); };
$("today-label").textContent = todayLabel();

function renderTasks(){
  const el=$("tasks-list");
  const tasks=[...store.state.tasks].sort((a,b)=>Number(!!a.completedAt)-Number(!!b.completedAt));
  if(!tasks.length){el.innerHTML='<p class="muted">No tasks yet.</p>';return;}
  el.innerHTML=tasks.map(t=>`<article class="item"><div class="item-main"><div class="item-title">${escapeHtml(t.title)} ${t.completedAt?'<span class="tag">Done</span>':`<span class="tag">${escapeHtml(t.priority)}</span>`}</div><div class="meta">${escapeHtml(t.category)}${t.dueAt?" · Due "+escapeHtml(new Date(t.dueAt).toLocaleString()):""}</div></div><div class="item-actions"><button data-task-toggle="${t.id}" type="button">${t.completedAt?"Undo":"Complete"}</button><button data-task-delete="${t.id}" type="button">Delete</button></div></article>`).join("");
}
function renderHabits(){
  const el=$("habits-list"), today=localDateKey();
  if(!store.state.habits.length){el.innerHTML='<p class="muted">Add habits you want to build.</p>';return;}
  el.innerHTML=store.state.habits.map(h=>{const done=(h.completedDays||[]).includes(today);return `<article class="item"><div class="item-main"><div class="item-title">${escapeHtml(h.title)}</div><div class="meta">${(h.completedDays||[]).length} total check-ins</div></div><div class="item-actions"><button data-habit-toggle="${h.id}" type="button">${done?"Completed today":"Mark today done"}</button></div></article>`}).join("");
}
function renderHealth(){
  const today=localDateKey(), all=store.state.measurements.filter(m=>m.day===today);
  const rows=all.slice().reverse().slice(0,8);
  const latestStep=all.filter(m=>m.metric==="steps").slice().sort((a,b)=>new Date(b.at)-new Date(a.at))[0];
  const steps=latestStep?.value || 0;
  const active=all.filter(m=>m.metric==="activeMinutes").reduce((n,m)=>n+m.value,0);
  const heart=all.filter(m=>m.metric==="heartRateBpm").slice().sort((a,b)=>new Date(b.at)-new Date(a.at))[0];
  $("steps-today").textContent=number(steps); $("steps-source").textContent=latestStep?`Latest reading · ${latestStep.source}`:"No device data yet";
  $("active-today").innerHTML=`${number(active)} <small>min</small>`;
  $("heart-today").innerHTML=heart?`${number(heart.value)} <small>bpm</small>`:'— <small>bpm</small>';
  $("heart-source").textContent=heart?`${heart.source} · ${new Date(heart.at).toLocaleTimeString()}`:"No reading yet";
  $("health-summary").innerHTML=rows.length?rows.map(m=>`<article class="item"><div class="item-main"><div class="item-title">${escapeHtml(METRICS[m.metric]?.label||m.metric)}: ${number(m.value)} ${escapeHtml(m.unit)}</div><div class="meta">${new Date(m.at).toLocaleTimeString()} · ${escapeHtml(m.source)}</div></div></article>`).join(""):'<p class="muted">No measurements logged today.</p>';
}
const DEVICE_OPTIONS = [
  {id:"apple",name:"Apple Health / Apple Watch",icon:"⌚",detail:"Needs a native iOS app using HealthKit and your permission. Safari cannot read Apple Health directly."},
  {id:"android",name:"Android Health Connect",icon:"◈",detail:"Needs an Android companion app and Health Connect permissions. Your watch must sync its data there."},
  {id:"samsung",name:"Samsung Health / Galaxy Watch",icon:"◉",detail:"Can be supported through Health Connect or an approved Samsung integration; no direct browser access."},
  {id:"fitbit",name:"Fitbit",icon:"⌁",detail:"Requires Fitbit account OAuth and an approved API integration with a secure backend."},
  {id:"garmin",name:"Garmin Connect",icon:"⌖",detail:"Requires Garmin Health API/partner access and a secure backend."},
  {id:"amazfit",name:"Zepp / Amazfit",icon:"◌",detail:"Requires a supported export or official integration; direct Bluetooth pairing does not expose health records."},
  {id:"huawei",name:"Huawei Health",icon:"◇",detail:"Requires a supported Huawei Health integration/export and user permission."}
];
function renderIntegrations(){
  $("device-hub").innerHTML=DEVICE_OPTIONS.map(p=>`<article class="device-card"><span class="device-icon" aria-hidden="true">${p.icon}</span><div><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.detail)}</p><button type="button" data-device-connect="${p.id}">Connect</button></div></article>`).join("");
}
function runSecurityChecks(){
  const secure=location.protocol==="https:"||location.hostname==="localhost"||location.hostname==="127.0.0.1";
  const storage=(()=>{try{const k="lifeos.security.check";localStorage.setItem(k,"1");localStorage.removeItem(k);return true}catch{return false}})();
  const configuredUrl = (() => { try { return isAuthConfigured() && new URL(AUTH_CONFIG.url).protocol === "https:"; } catch { return false; } })();
  const csp = Boolean(document.querySelector('meta[http-equiv="Content-Security-Policy"]'));
  const keyRole = (() => { try { const part=AUTH_CONFIG.anonKey.split(".")[1]; if(!part)return "unknown"; const payload=JSON.parse(atob(part.replace(/-/g,"+").replace(/_/g,"/"))); return payload.role || "unknown"; } catch { return "unknown"; } })();
  const publicKeySafe = !isAuthConfigured() || keyRole === "anon" || keyRole === "authenticated";
  const checks=[
    {name:"Secure connection",detail:secure?"HTTPS or local development context detected.":"Use HTTPS before entering account data.",status:secure?"pass":"fail"},
    {name:"Content Security Policy",detail:csp?"A restrictive meta CSP is present; hosting response headers are still required for full protection.":"No Content Security Policy found.",status:csp?"pass":"fail"},
    {name:"Authentication backend",detail:configuredUrl?"Supabase HTTPS endpoint and public key are configured.":"Not configured or endpoint is not HTTPS; live sign-in is unavailable.",status:configuredUrl?"pass":"warn"},
    {name:"Client key role",detail:!isAuthConfigured()?"No client key configured.":publicKeySafe?"No service-role claim detected in the configured client key.":"Danger: configured key appears privileged. Remove it from client code immediately.",status:publicKeySafe?"pass":"fail"},
    {name:"Account data separation",detail:store.scope==="demo"?"Demo workspace is isolated from account namespaces.":"Local data uses a per-account storage namespace; this is not server authorization.",status:"pass"},
    {name:"Browser storage",detail:storage?"Local storage is available.":"Local storage is blocked or unavailable.",status:storage?"pass":"fail"},
    {name:"Cloud authorization (RLS)",detail:"Cannot be verified in this browser. Enable and test Supabase Row Level Security before cloud sync.",status:"warn"},
    {name:"Bluetooth capability",detail:ble.supported?"Web Bluetooth API detected; device/service compatibility still depends on the watch.":"Web Bluetooth is unavailable in this browser. A native BLE host is required on iPhone.",status:ble.supported?"pass":"warn"},
    {name:"Health permissions",detail:globalThis.LifeOSHealthBridge?"Native health bridge detected; grant permissions in the operating system before reading records.":"No native HealthKit/Health Connect bridge detected.",status:globalThis.LifeOSHealthBridge?"warn":"warn"}
  ];
  $("security-results").innerHTML=checks.map(c=>`<article class="security-check"><div><b>${escapeHtml(c.name)}</b><small>${escapeHtml(c.detail)}</small></div><span class="security-status ${c.status}">${c.status==="pass"?"Pass":c.status==="fail"?"Action needed":"Pending"}</span></article>`).join("");
}
function render(){if(!store)return;renderTasks();renderHabits();renderHealth();renderIntegrations();}

$("task-form").addEventListener("submit",e=>{e.preventDefault();try{commit(s=>addTask(s,{title:$("task-title").value,priority:$("task-priority").value,category:$("task-category").value,dueAt:$("task-due").value?new Date($("task-due").value).toISOString():null}));$("task-form").reset()}catch(err){alert(err.message)}});
$("tasks-list").addEventListener("click",e=>{const t=e.target.closest("[data-task-toggle]"),d=e.target.closest("[data-task-delete]");if(t)commit(s=>completeTask(s,t.dataset.taskToggle));if(d)commit(s=>deleteTask(s,d.dataset.taskDelete))});
$("habit-form").addEventListener("submit",e=>{e.preventDefault();try{commit(s=>addHabit(s,$("habit-title").value));$("habit-title").value=""}catch(err){alert(err.message)}});
$("habits-list").addEventListener("click",e=>{const b=e.target.closest("[data-habit-toggle]");if(b)commit(s=>toggleHabitToday(s,b.dataset.habitToggle))});
$("health-form").addEventListener("submit",e=>{e.preventDefault();try{commit(s=>logMeasurement(s,$("health-metric").value,$("health-value").value,"manual"));$("health-value").value=""}catch(err){alert(err.message)}});
const ble = new LifeOSBluetooth({
  onStatus(status) {
    const state = $("ble-state");
    state.textContent = status.state === "connected" ? "Connected" : status.state === "scanning" ? "Scanning" : status.state === "connecting" ? "Connecting" : "Not connected";
    $("ble-message").textContent = status.message;
    $("ble-connect").disabled = ["scanning", "connecting", "connected"].includes(status.state);
    $("ble-disconnect").disabled = status.state !== "connected";
    if (status.bpm) $("ble-heart").textContent = `${status.bpm} bpm`;
    if (Number.isInteger(status.battery)) $("ble-battery").textContent = `${status.battery}%`;
    if (status.state === "disconnected") { $("ble-heart").textContent = "—"; $("ble-battery").textContent = "—"; }
  },
  onMeasurement(record) {
    if (!store || !METRICS[record.metric]) return;
    commit(state => logMeasurement(state, record.metric, record.value, record.source, new Date(record.at)));
  }
});
$("ble-capability").textContent = ble.supported ? "Ready · compatible browser detected" : "Unavailable in this browser · native iOS/Android integration required";
$("ble-connect").addEventListener("click", async () => {
  $("ble-connect").disabled = true;
  try {
    const device = await ble.connect();
    $("device-message").textContent = `${device.name} is paired for this browser session. Keep this page open for live BLE notifications.`;
    $("ble-steps").textContent = "Not exposed by standard BLE";
  } catch (error) {
    $("ble-message").textContent = error?.name === "NotFoundError" ? "No device selected." : (error?.message || "Bluetooth connection failed.");
    $("ble-state").textContent = "Not connected";
    $("ble-connect").disabled = false;
  }
});
$("ble-disconnect").addEventListener("click", () => ble.disconnect());

$("device-hub").addEventListener("click",async e=>{
  const b=e.target.closest("[data-device-connect]");if(!b)return;
  const p=DEVICE_OPTIONS.find(x=>x.id===b.dataset.deviceConnect);
  const bridge=globalThis.LifeOSHealthBridge;
  if(!bridge || typeof bridge.requestAuthorization!=="function" || typeof bridge.readToday!=="function"){
    $("device-message").textContent=`${p.name}: this provider requires its native health permission/API integration. The generic BLE connection above cannot replace it.`;
    return;
  }
  b.disabled=true;
  try{
    const permission=await bridge.requestAuthorization({provider:p.id,types:["steps","heartRateBpm","activeMinutes"]});
    if(!permission?.granted) throw new Error("Permission was not granted.");
    const result=await bridge.readToday({provider:p.id,types:["steps","heartRateBpm","activeMinutes"]});
    let imported=0;
    commit(state=>{
      for(const item of (Array.isArray(result?.records)?result.records:[])){
        if(!METRICS[item.metric] || !Number.isFinite(Number(item.value)) || Number(item.value)<0) continue;
        const at=item.at?new Date(item.at):new Date(); if(Number.isNaN(at.getTime())) continue;
        logMeasurement(state,item.metric,Number(item.value),String(item.source||p.name),at); imported++;
      }
    });
    $("device-message").textContent=`${p.name}: imported ${imported} verified record(s).`;
  }catch(error){$("device-message").textContent=`${p.name}: ${error.message||"Connection failed."}`;}
  finally{b.disabled=false;}
});
$("security-refresh").addEventListener("click",runSecurityChecks);
$("health-import-btn").addEventListener("click",()=>$("health-import-file").click());
$("health-import-file").addEventListener("change",async e=>{
  const file=e.target.files?.[0];if(!file)return;
  try{
    const text=await file.text(), lines=text.split(/\r?\n/).filter(Boolean);if(lines.length<2)throw new Error("CSV needs a header and at least one data row.");
    const headers=lines.shift().split(",").map(x=>x.trim().toLowerCase());
    const idx={metric:headers.indexOf("metric"),value:headers.indexOf("value"),at:headers.indexOf("at"),source:headers.indexOf("source")};
    if(idx.metric<0||idx.value<0)throw new Error("CSV headers must include metric,value. Optional: at,source.");
    let count=0;
    commit(state=>{for(const line of lines){const cols=line.split(",").map(x=>x.trim()),metric=cols[idx.metric],value=Number(cols[idx.value]);if(!METRICS[metric]||!Number.isFinite(value)||value<0)continue;const at=idx.at>=0&&cols[idx.at]?new Date(cols[idx.at]):new Date();if(Number.isNaN(at.getTime()))continue;logMeasurement(state,metric,value,"csv-import",at);count++;}});
    $("device-message").textContent=`Imported ${count} valid measurement(s). Source is labelled CSV import; verify the file came from your trusted health app.`;
  }catch(err){$("device-message").textContent=err.message;}finally{e.target.value="";}
});
$("export-btn").addEventListener("click",()=>{const blob=new Blob([store.export()],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`lifeos-backup-${localDateKey()}.json`;a.click();URL.revokeObjectURL(url)});
$("import-file").addEventListener("change",async e=>{const f=e.target.files?.[0];if(!f)return;try{store.import(await f.text());render();alert("Backup imported.")}catch(err){alert(err.message)}e.target.value=""});
$("reset-data").addEventListener("click",()=>{if(confirm("Permanently clear all LifeOS data stored in this browser? Export a backup first if needed.")){store.reset();render()}});
let remaining=25*60, interval=null, endAt=null;
function showTimer(){$("timer-display").textContent=`${String(Math.floor(remaining/60)).padStart(2,"0")}:${String(remaining%60).padStart(2,"0")}`}
function resetTimer(){clearInterval(interval);interval=null;remaining=Math.max(1,Math.min(180,Number($("focus-length").value)||25))*60;endAt=null;$("timer-start").textContent="Start";showTimer()}
$("focus-length").addEventListener("change",resetTimer);
$("timer-reset").addEventListener("click",resetTimer);
$("timer-start").addEventListener("click",()=>{
  if(interval){clearInterval(interval);interval=null;$("timer-start").textContent="Resume";return}
  if(remaining<=0)resetTimer();
  endAt=Date.now()+remaining*1000;$("timer-start").textContent="Pause";
  interval=setInterval(()=>{
    remaining=Math.max(0,Math.ceil((endAt-Date.now())/1000));showTimer();
    if(remaining===0){clearInterval(interval);interval=null;$("timer-start").textContent="Start";commit(s=>{s.focusSessions.push({id:crypto.randomUUID(),minutes:Math.max(1,Math.min(180,Number($("focus-length").value)||25)),completedAt:new Date().toISOString(),day:localDateKey()});logMeasurement(s,"focusMinutes",Math.max(1,Math.min(180,Number($("focus-length").value)||25)),"timer")});alert("Focus session complete.");}
  },250);
});
resetTimer();