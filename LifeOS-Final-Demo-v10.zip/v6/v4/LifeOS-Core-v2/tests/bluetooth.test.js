import test from 'node:test';
import assert from 'node:assert/strict';
import { parseHeartRate } from '../js/integrations/bluetooth.js';
const view = bytes => new DataView(Uint8Array.from(bytes).buffer);
test('parses standard 8-bit heart-rate measurement', () => assert.equal(parseHeartRate(view([0, 72])), 72));
test('parses standard 16-bit heart-rate measurement', () => assert.equal(parseHeartRate(view([1, 44, 1])), 300));
test('rejects malformed or out-of-range sensor values', () => {
  assert.equal(parseHeartRate(null), null);
  assert.equal(parseHeartRate(view([1, 70])), null);
  assert.equal(parseHeartRate(view([0, 0])), null);
  assert.equal(parseHeartRate(view([0, 255])), 255);
  assert.equal(parseHeartRate(view([1, 45, 1])), null);
});
