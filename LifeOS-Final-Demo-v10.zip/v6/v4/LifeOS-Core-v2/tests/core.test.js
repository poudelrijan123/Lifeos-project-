// Run with: node --test tests/core.test.js
import test from "node:test";
import assert from "node:assert/strict";
import { setTarget, targetProgress, logMeasurement } from "../js/core/targets.js";
import { addTask, completeTask } from "../js/core/tasks.js";
import { addGoal, updateGoalProgress } from "../js/core/goals.js";

const state = () => ({targets:[],measurements:[],tasks:[],goals:[]});
test("daily target accumulates measurements and caps progress",()=>{
  const s=state(); setTarget(s,"steps",5000); logMeasurement(s,"steps",2000);
  logMeasurement(s,"steps",4000);
  const p=targetProgress(s,s.targets[0]);
  assert.equal(p.currentValue,6000); assert.equal(p.percent,100); assert.equal(p.complete,true);
});
test("heart rate cannot be configured as a daily target",()=>{
  assert.throws(()=>setTarget(state(),"heartRateBpm",100));
});
test("task completion toggles",()=>{
  const s=state(); addTask(s,{title:"Study",priority:"high"}); const id=s.tasks[0].id;
  completeTask(s,id); assert.ok(s.tasks[0].completedAt); completeTask(s,id); assert.equal(s.tasks[0].completedAt,null);
});
test("goal progress cannot fall below zero",()=>{
  const s=state(); addGoal(s,{title:"Project",targetValue:5,unit:"steps"}); const id=s.goals[0].id;
  updateGoalProgress(s,id,-2); assert.equal(s.goals[0].currentValue,0);
});
import { Store } from "../js/core/store.js";
class MemoryStorage {
  constructor() { this.data = new Map(); }
  getItem(key) { return this.data.has(key) ? this.data.get(key) : null; }
  setItem(key, value) { this.data.set(key, String(value)); }
  removeItem(key) { this.data.delete(key); }
}
test("account namespaces keep local data separate", () => {
  const storage = new MemoryStorage();
  const accountA = new Store(storage, "account-a");
  accountA.update(s => s.tasks.push({ id: "a1", title: "Private task" }));
  const accountB = new Store(storage, "account-b");
  assert.equal(accountB.state.tasks.length, 0);
  assert.equal(new Store(storage, "account-a").state.tasks[0].title, "Private task");
});
test("legacy unscoped data migrates only into demo mode", () => {
  const storage = new MemoryStorage();
  storage.setItem("lifeos.core.v2", JSON.stringify({ version: 2, tasks: [{ id: "old" }], targets: [] }));
  assert.equal(new Store(storage, "demo").state.tasks.length, 1);
  assert.equal(new Store(storage, "account-a").state.tasks.length, 0);
});
test("backup import rejects unrelated or malformed data", () => {
  const store = new Store(new MemoryStorage(), "demo");
  assert.throws(() => store.import("{}"), /valid LifeOS backup/);
});
