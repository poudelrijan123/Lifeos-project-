# LifeOS Core v2

A functional, local-first foundation for a personal operating system.

## Run
This is a static ES-module app. Serve the project folder with any static web host (GitHub Pages, Netlify, etc.). `index.html` must remain at the published root. Opening the file directly may block JavaScript modules in some browsers, so use a local static server during development.

## Included
- Tasks with priority, category, due date/time, complete and delete
- Daily habit check-ins
- Manual health measurements, including source-attributed heart-rate observations
- Steps and activity summaries based on recorded measurements
- Focus timer
- JSON backup export/import and local data reset
- Wearable integration entry points with honest connection status
- Account-scoped local storage namespaces

## Important limitations
- This is not a native iOS or Android app.
- It cannot directly connect to every watch.
- Apple Watch data requires a native iOS app using HealthKit.
- Android wearable data requires a native Android app using Health Connect, when the watch ecosystem supports it.
- Google cloud data requires a backend and OAuth integration.
- Garmin and some other vendor APIs may require partner/enterprise approval.
- Data is stored only in this browser's localStorage; there is no account or cross-device sync.
- No health diagnosis or heart-rate target is provided.

See `docs/ARCHITECTURE.md` and `docs/WATCH_INTEGRATIONS.md` before adding real device connections.


## Sign-in UI and auth structure

See [docs/AUTHENTICATION.md](./docs/AUTHENTICATION.md). The sign-in screen is a new entry layer; the existing local-first dashboard remains available through the clearly labelled demo entry. Real sign-in requires provider configuration.

Health and wearable integration status, platform limitations, CSV import format and production security requirements are documented in [docs/HEALTH_INTEGRATIONS.md](docs/HEALTH_INTEGRATIONS.md).


## Home welcome experience
After successful sign-in (or entering the demo), LifeOS displays a brief personalized welcome notification. It uses the account profile name when available, then falls back to the email name; demo mode uses a neutral greeting. The notification can be dismissed and respects reduced-motion preferences.

## Current scope and device connectivity

The main dashboard focuses on tasks, habits, health measurements, wearable integration entry points, and focus sessions. Goal tracking and configurable daily target panels have been removed from the primary experience to reduce clutter. Older backup fields are tolerated for compatibility but are not shown in the UI.

Real wearable synchronization requires a native iOS HealthKit or Android Health Connect host exposing the contract in `docs/NATIVE_HEALTH_BRIDGE.md`. The browser build does not claim universal Bluetooth health access.

### Bluetooth LE
The dashboard includes a browser Web Bluetooth LE module for compatible devices exposing the standard BLE Heart Rate, Battery, and Device Information services. It requires a supported Chromium browser and HTTPS/localhost. It is not a universal watch-health adapter: iOS Safari has no Web Bluetooth API, standard BLE does not expose daily step totals, and vendor-specific watch protocols require separate integrations. See `docs/WATCH_INTEGRATIONS.md`.

## Bluetooth and security hardening (v7)
- BLE parsing validates heart-rate payload length and range, rate-limits repeated notifications, and rejects malformed sensor data.
- Device identity strings are normalized; disconnect cleans up listeners; battery and device-info reads are optional and never block pairing.
- Standard BLE heart-rate service (0x180D), battery service (0x180F), and device information service (0x180A) are supported when exposed by the peripheral.
- A stricter Content Security Policy fallback and referrer policy are present. Backup import size and collection limits are enforced. See [Security Review](docs/SECURITY_REVIEW.md).
- 10 automated tests cover core behavior and BLE measurement parsing.

This is still a browser app, not a native mobile app. In particular, iPhone browsers do not provide Web Bluetooth. The BLE code cannot read daily step totals from the standard heart-rate service and cannot bypass manufacturer watch ecosystems. Native iOS HealthKit and Android Health Connect apps remain required for broad health-data access. Do not describe every watch as compatible until tested against that exact model and its supported data path.


## v10 local demo authentication
This build intentionally uses **simulated sign-in** for GitHub preview/testing. Google, Apple, Facebook and email options enter the local demo dashboard only. No provider is contacted, no password is requested or stored, and no real account is created. Demo data is stored locally in this browser and is not synced across devices. Do not present this demo as secure production authentication.
