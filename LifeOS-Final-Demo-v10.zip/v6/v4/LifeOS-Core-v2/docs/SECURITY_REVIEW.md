# LifeOS security review (web prototype)

## Controls added
- Content Security Policy limits scripts to same-origin, blocks objects, restricts base URI and form destinations, and permits only the configured Supabase origin pattern for network calls.
- Referrer policy is `strict-origin-when-cross-origin`.
- Health values from BLE are range-checked, malformed payloads are ignored, and duplicate high-frequency notifications are rate-limited.
- Device names are normalized before being used in UI status text.
- Backup imports have a 5 MB cap and per-collection limits before state replacement.
- Account storage uses separate namespaces; authentication sessions remain in session storage, not persistent local storage.

## Release-blocking items (not verifiable or solvable from this static browser project)
- Configure a real authentication backend and verify provider callbacks, email confirmation, password reset, and token revocation.
- Enable database Row Level Security and test cross-account isolation on the server. A client-side namespace is not authorization.
- Add native iOS HealthKit and Android Health Connect implementations, platform permission declarations, and real-device testing.
- Configure server response headers (CSP, HSTS, Permissions-Policy, X-Content-Type-Options, frame protections) at the hosting layer. A meta CSP is only a partial fallback and cannot set all headers.
- Add dependency scanning, secret scanning, automated deployment checks, backup recovery tests, privacy policy, and incident response process before production.

Never ship service-role keys, OAuth client secrets, or provider refresh tokens in browser code. Do not treat a BLE pairing as permission to access all health history. Ask permission per platform and record source/time for each measurement.
