# LifeOS health and wearable integrations

## Current prototype capabilities

- Dashboard cards summarize today's step, active-minute and latest heart-rate entries.
- Measurements can be entered manually or imported from CSV.
- CSV requires `metric,value` headers. Optional headers: `at,source`.
- Supported metric keys: `steps`, `waterMl`, `sleepMinutes`, `activeMinutes`, `focusMinutes`, `heartRateBpm`.
- Imported values are labelled `csv-import`; verify the export source before importing.
- The device hub explains the real integration requirements for Apple Health/Watch, Android Health Connect, Samsung Health, Fitbit, Garmin, Zepp/Amazfit and Huawei Health.

## Important platform limitations

This project is currently a browser-based web app. A web page cannot universally read Apple Health, Android Health Connect, Samsung Health or arbitrary watch sensor data. Bluetooth discovery is not the same as permission to read a watch's health records. A device being paired in phone settings does not mean LifeOS can access its measurements.

For real step and heart-rate synchronization, build platform bridges:

1. iOS app target with HealthKit capability, entitlements, purpose strings and per-data-type read permissions.
2. Android app target using Health Connect permissions and records APIs.
3. Optional provider OAuth integrations (for example Fitbit/Garmin) through a backend; keep client secrets on the server.
4. Normalize records, timestamps, units, provenance and duplicate handling before writing to a user's account.
5. Ask for only the health data types needed and let users revoke access and disconnect.

Heart rate must be displayed as a source-attributed measurement, not inferred from motion or presented as a diagnosis. Step totals from multiple sources must not be blindly added because this can double-count the same activity.

## CSV example

```csv
metric,value,at,source
steps,5420,2026-11-06T08:30:00+05:45,Apple Health export
heartRateBpm,82,2026-11-06T08:31:00+05:45,Apple Health export
activeMinutes,35,2026-11-06T08:31:00+05:45,Apple Health export
```

## Security before cloud sync

- Configure Supabase Auth and redirect URLs.
- Create per-user tables and enable Row Level Security (RLS) on every health-data table.
- Policies must bind rows to `auth.uid()`; test cross-user reads and writes with separate accounts.
- Keep Supabase service-role keys and provider OAuth client secrets on the server only.
- Obtain explicit consent for health data, support deletion/export, and define retention rules.
- Use HTTPS and validate imported data server-side before accepting it into cloud storage.

The dashboard's security panel performs basic local configuration checks only. It is not a penetration test and cannot verify remote Supabase policies from a static browser client.
