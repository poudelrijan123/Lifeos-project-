# LifeOS Core architecture

## Product boundary
LifeOS is a personal operating system: daily execution (tasks), routines (habits), measurable long-term outcomes (goals), daily targets, focus sessions, and health/activity observations.

## Core principles
1. **One normalized data model.** Every integration maps provider records to `{ metric, value, unit, at, source }`.
2. **Source transparency.** Every measurement records whether it came from manual entry, a timer, or a verified provider.
3. **No invented sensor data.** A connection is not considered active until a real adapter has authenticated and returned records.
4. **User-controlled targets.** Daily targets are configurable and editable. Heart rate is an observation only, not a performance target.
5. **Local-first for this prototype.** Data stays in this browser's localStorage. It does not sync across devices.
6. **Versioned backups.** JSON export/import preserves user data and supports schema versioning.

## Main domain objects
- Target: metric, targetValue, period=daily.
- Measurement: metric, value, unit, timestamp, local day, source.
- Task: title, priority, category, dueAt, completedAt.
- Habit: title, completedDays.
- Goal: title, targetValue, currentValue, unit, dueDate.
- Focus session: minutes, completedAt, local day.

## Daily target calculation
A target's progress is the sum of measurements for that metric on the user's local calendar day divided by the configured target. Progress is capped visually at 100%; raw values remain available. This lets users enter multiple measurements throughout the day.

## Next production steps
1. Add account authentication and a secure server database if cross-device sync is required.
2. Build native iOS companion app with HealthKit entitlement and granular permission requests.
3. Build native Android companion app using Health Connect permissions.
4. Add provider OAuth/server adapters (e.g. Google Health API) only after reviewing provider access and data policies.
5. Add conflict handling, duplicate detection, deletion propagation, consent revocation, audit logs, and encryption at rest/in transit.
6. Add automated tests and accessibility review before public release.


## Brand intro
The app starts with a short, CSS-animated LifeOS splash screen. Its inline SVG symbol is shared with the sign-in brand marks, so the icon stays consistent without loading an external image. The intro exits into the existing sign-in screen; reduced-motion preferences are respected and a JavaScript fallback prevents the splash from blocking the app if animation events are unavailable.

## Account-scoped local data foundation
The browser store now uses a separate localStorage namespace for each authenticated user ID, with a separate `demo` namespace. Existing unscoped prototype data is migrated into demo mode only, so it is not silently exposed to a newly signed-in account. Backups remain portable JSON files and are imported into the currently active namespace.

**Important security boundary:** this is local device separation only. It does not provide cross-device sync, server-side access control, encryption guarantees, or protection from someone with access to the same browser profile/devtools. Production multi-device accounts require a backend database with row-level security policies tied to the authenticated user ID. Do not store provider secrets or Supabase service-role keys in client code.
