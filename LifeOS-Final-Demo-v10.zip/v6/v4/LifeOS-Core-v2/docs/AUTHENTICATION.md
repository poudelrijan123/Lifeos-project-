# LifeOS authentication structure

The existing LifeOS Core v2 dashboard and feature modules are preserved. Authentication is isolated under `js/auth/`.

- `config.js` — public Supabase project URL and anon key placeholders.
- `auth-service.js` — email/password and OAuth provider request boundary.
- `auth-ui.js` — sign-in/create-account tabs, validation, status messages and demo entry.
- `css/auth.css` — responsive sign-in experience.

## Connect real authentication

1. Create a Supabase project and enable Email, Google, Apple and Facebook providers in its Authentication settings.
2. Add the exact local/deployed site URL and callback/redirect URLs to Supabase and each provider's developer console.
3. Put the Supabase **project URL** and **anon/public key only** in `js/auth/config.js`. Never put a service-role key, OAuth client secret, or other private credential in browser code or Git.
4. Configure email confirmation and password reset redirect/template settings.
5. Test each provider on localhost and the deployed HTTPS domain.

The current **Explore the demo** button opens the existing local-first dashboard without claiming a user is authenticated. Until configuration is supplied, login/provider actions report that setup is missing rather than pretending to sign in. For production, the next step is to use the Supabase SDK for refresh-token/session lifecycle and enforce per-user row-level security policies before syncing personal data.


## Social sign-in callback

Google, Apple, and Facebook buttons start Supabase OAuth and return to the app URL. The app handles the provider callback, validates the access token against Supabase, and keeps the session in `sessionStorage` for the current browser tab. It attempts token refresh when a saved session is close to expiry. Provider credentials must be configured in Supabase and each provider console; the frontend only contains the Supabase project URL and public anon key.

Before production, configure the deployed origin in Supabase Auth URL Configuration and each provider's allowed redirect/callback URLs. Keep provider client secrets and any service-role key out of this repository.
