# LifeOS native health bridge contract

## Current status
The current project is a browser-based web app. It cannot directly read Apple Health/HealthKit, Android Health Connect, or arbitrary wearable sensor data. The connection UI detects a native bridge and refuses to claim a connection when one is absent.

## Contract expected from a native shell
A trusted native iOS/Android host may expose `window.LifeOSHealthBridge` to the LifeOS UI with:
- `platform`: `ios` or `android`
- `capabilities`: supported record types
- `requestAuthorization({ provider, types })`: resolves to `{ granted: boolean }` only after the OS permission flow
- `readToday({ provider, types })`: resolves to `{ records: [{ metric, value, at, source }] }`

Allowed metric keys: `steps`, `heartRateBpm`, `activeMinutes`, `sleepMinutes`, `waterMl`, `focusMinutes`.

## iOS implementation required
- Native Swift app target with HealthKit capability and entitlements.
- Clear `NSHealthShareUsageDescription` and (only if writing data) `NSHealthUpdateUsageDescription` purpose strings.
- Request only the read access needed for step count, heart rate, and active activity data.
- Query HealthKit with source attribution and timestamps. Respect denied/revoked permissions.
- Do not infer read permission from an authorization status that iOS intentionally does not expose; report only data actually returned.

## Android implementation required
- Native Kotlin app target with Health Connect availability/version checks.
- Declare required Health Connect permissions and explain their purpose.
- Request runtime permissions only when the user enables the feature.
- Read records using Health Connect APIs with timestamps and data-origin metadata.
- Handle unavailable, revoked, and partial-permission states.

## Provider integrations
Fitbit, Garmin, and other cloud APIs require provider-specific OAuth and server-side token storage. Never put OAuth client secrets or refresh tokens in browser JavaScript. Avoid summing duplicate step totals from multiple sources.

## Release gate
Do not mark a wearable connected until OS/provider authorization succeeds and LifeOS receives valid, source-attributed records. Test on real supported devices. The web prototype alone cannot complete these native integrations.
