# Watch compatibility: what is actually possible

## Important
A browser-based website cannot directly read every smartwatch. There is no universal smartwatch API. Data access depends on the watch maker, its companion app, phone OS, permissions, and developer access.

## Apple Watch / iPhone
Use a native iOS companion app with Apple's HealthKit capability. Request only the health data types LifeOS needs, explain why, and respect the user's per-type permissions. The iOS app can normalize authorized records and sync them to the LifeOS backend. A web app by itself cannot call HealthKit.

## Android watches
Use a native Android companion app with Health Connect. A watch can contribute only the data that its companion app writes into Health Connect and that the user authorizes. Coverage differs by manufacturer and metric.

## Google / Fitbit / Pixel
For cloud/web integrations, evaluate the current Google Health API and its OAuth requirements. For Android mobile-first access, evaluate Health Connect. Do not start a new integration on Google Fit APIs: Google's migration documentation says Fit APIs are supported only through the end of 2026.

## Garmin and other manufacturers
Some vendors provide partner, enterprise, or restricted APIs/SDKs. Garmin's Health API/SDK access is not a universal public Bluetooth connection. Other brands may expose data through Health Connect or Apple Health, or may require their own developer program.

## Universal fallback
Provide manual entry and a documented import path. Never show a fake "connected" badge or fabricate heart-rate/step readings. Each measurement must preserve its source and timestamp.

## Proposed implementation order
1. Manual entry + normalized measurements (implemented in this core).
2. iOS HealthKit bridge (native app).
3. Android Health Connect bridge (native app).
4. Google Health API cloud integration (backend + OAuth).
5. Vendor-specific integrations based on user demand and approved access.

## Generic Bluetooth LE support (web build)

The dashboard now includes a real Web Bluetooth LE pairing module in `js/integrations/bluetooth.js`.

- Uses the browser's device chooser after a user tap; it does not scan silently.
- Connects over GATT and listens for the standard Heart Rate Service (`0x180D`, characteristic `0x2A37`). Live BPM notifications are stored in the LifeOS health log with the BLE device name as their source.
- Reads Battery Service (`0x180F`, characteristic `0x2A19`) and optional Device Information Service (`0x180A`).
- Disconnects cleanly and does not claim a device is connected after a failed pairing.
- Requires HTTPS (or localhost) and a browser with Web Bluetooth support, typically Chromium on Android or desktop.

**Platform and device limits:** iOS Safari does not expose Web Bluetooth, so this module cannot pair watches from the current iPhone web app. A native iOS target with HealthKit is required for Apple Watch and Apple Health. Android should use a native Health Connect integration for aggregated step/sleep/activity history. The standard BLE Heart Rate Service provides heart rate, not daily step totals. Many consumer watches use private/vendor GATT services or keep health data inside their companion apps; they need separate documented protocol/API integrations. The device chooser accepting a watch does not guarantee its health data is readable.
